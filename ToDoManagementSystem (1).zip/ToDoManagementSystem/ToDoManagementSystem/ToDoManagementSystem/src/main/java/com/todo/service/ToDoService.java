package com.todo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todo.model.Todo;
import com.todo.model.User;
import com.todo.repository.ToDoRepository;

@Service
public class ToDoService {

	@Autowired
    private ToDoRepository todoRepository;

	public List<Todo> getTodosForUser(User user) {
        return todoRepository.findByUser(user);
    }

    public Todo addTodoForUser(Todo todo, User user) {
        todo.setUser(user); // ensure security
        return todoRepository.save(todo);
    }

    public Todo updateTodoForUser(Long id, Todo updatedTodo, User user) {
        Todo existing = todoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Todo not found"));

        if (!existing.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized");
        }

        existing.setTask(updatedTodo.getTask());
        existing.setCompleted(updatedTodo.isCompleted());
        return todoRepository.save(existing);
    }

    public void deleteTodoForUser(Long id, User user) {
        Todo todo = todoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Todo not found"));

        if (!todo.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized");
        }

        todoRepository.delete(todo);
    }
}