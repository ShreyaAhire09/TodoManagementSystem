package com.todo.model;

import lombok.Data;

@Data
public class TodoRequestDto {
private String task;
private boolean completed;
public Todo toEntity(User user) {
    Todo todo = new Todo();
    todo.setTask(this.task);
    todo.setCompleted(this.completed);
    todo.setUser(user);
    return todo;
}
}
