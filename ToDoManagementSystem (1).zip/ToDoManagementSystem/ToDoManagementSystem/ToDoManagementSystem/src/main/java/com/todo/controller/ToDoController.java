package com.todo.controller;


import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.todo.model.Todo;
import com.todo.model.TodoRequestDto;
import com.todo.model.User;
import com.todo.service.ToDoService;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class ToDoController {

    @Autowired
    private ToDoService todoService;

    private User getSessionUser(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new RuntimeException("User not logged in");
        }
        return user;
    }

    @GetMapping
    public List<Todo> getTodos(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new RuntimeException("User not logged in");
        }
        return todoService.getTodosForUser(user);
    }

    @PostMapping
    public Todo addTodo(@RequestBody Todo todo, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new RuntimeException("User not logged in");
        }
        todo.setUser(user);
        return todoService.addTodoForUser(todo, user);
    }

    @PutMapping("/{id}")
    public Todo updateTodo(@PathVariable Long id, @RequestBody TodoRequestDto dto, HttpSession session) {
        User user = getSessionUser(session);
        Todo updated = dto.toEntity(user);
        updated.setId(id);
        return todoService.updateTodoForUser(id, updated, user);
    }

    @DeleteMapping("/{id}")
    public void deleteTodo(@PathVariable Long id, HttpSession session) {
        todoService.deleteTodoForUser(id, getSessionUser(session));
    }
}
