package com.todo.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.todo.model.LoginRequest;
import com.todo.model.User;
import com.todo.service.UserService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class UserController {

    @Autowired
    private UserService userService;

    // Register new user
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        if (userService.findByUsername(user.getUsername()) != null) {
            return ResponseEntity.badRequest().body("User already exists");
        }
        userService.save(user);
        return ResponseEntity.ok("Registered successfully");
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request, HttpSession session) {
        if (userService.validateUser(request.getUsername(), request.getPassword())) {
            User user = userService.findByUsername(request.getUsername());
            session.setAttribute("user", user);
            return "Login successful";
        }
        throw new RuntimeException("Invalid username or password");
    }

    // Logout by invalidating session
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "Logged out";
    }

    // Get currently logged-in user
    @GetMapping("/user")
    public User getUser(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new RuntimeException("Not logged in");
        }
        return user;
    }
}
